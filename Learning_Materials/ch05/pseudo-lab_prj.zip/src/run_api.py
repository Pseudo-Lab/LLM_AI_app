from fastapi import FastAPI
import uvicorn

from langserve import add_routes
from src.graphs.graph_builder import build_graph


'''
기본 베이스는 FastAPI 입니다.
여기에 langserve를 사용하여 api 서버를 구현하였습니다.
'''
app = FastAPI()
runnable_chain = build_graph() # LangGraph workflow build
add_routes(app, runnable_chain, path="/graphbot") # LangServe API 추가

if __name__ == "__main__":
    uvicorn.run("src.run_api:app", host="0.0.0.0", port=8000, reload=True)