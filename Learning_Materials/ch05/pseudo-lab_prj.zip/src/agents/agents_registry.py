from langchain.agents import (
    initialize_agent, 
    AgentType
)

from src.agents.paper.agent import paper_tools
from src.agents.weather.agent import weather_tools

from src.chains.chain_registry import (
    paper_chain,
    weather_chain
)


'''
paper agent 선언 메서드 입니다.

initalize_agent 메서드는 
agent를 선언하기 가장 간편한 메서드 입니다.

주요 파라미터는 아래와 같습니다.


toools: 
'''
paper_agent = initialize_agent(
    tools=paper_tools,
    llm=paper_chain,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    handle_parse_errors=True,
    verbose=True
)


'''
weather_agent
'''
weather_agent = initialize_agent(
    tools=weather_tools,
    llm=weather_chain,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    handle_parse_errors=True,
    verbose=True
)



if __name__ == "__main__":
    # print("================== paper_agent test ==================")
    # print(paper_agent.invoke("https://arxiv.org/abs/2210.03629 다운 받아서 vector db에 저장해"))
    # print(paper_agent.invoke("응 요약본도 알려줄래?"))
    # print("\n\n\n")
    # print("================== weather_agent test ==================")
    # print(weather_agent.invoke("오늘 날씨와 추천 복장 알려줘"))
    # print("\n\n\n")

    while True:
        user_input = input("input: ")
        print(paper_agent.invoke(user_input))
