from langchain.schema import StrOutputParser 



WEATHER_PARSER = StrOutputParser()

PAPER_PARSER = StrOutputParser()

CATEGORIZE_PARSER = StrOutputParser()

DEFAULT_PARSER = StrOutputParser()