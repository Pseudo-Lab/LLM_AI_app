from langchain.schema.runnable import Runnable
from langchain_core.prompt_values import StringPromptValue, ChatPromptValue
from langchain_core.messages import HumanMessage, AIMessage




class MemoryStorage:
    '''
    MemoryStorage는 메모리에 저장된 대화 내용을 저장하는 클래스
    '''
    def __init__(self):
        self.chat_history = ["<CHAT_HISTORY_START>"] # 시작 문자열

    
class MemoryInput(Runnable):
    '''
    MemoryStorage에 저장된 대화 내용을 불러오는 Runnable
    '''
    def __init__(self, chat_history: MemoryStorage):
        self.chat_history = chat_history

    def invoke(self, inputs, config=None, **kwargs):
        '''
        invoke 함수 구현시
        input, config, **kwargs
        반드시 만들어주어야 합니다!
        '''
        print("================== user_input ==================")
        print(type(inputs))
        print()
        print(inputs)
        print("================== user_input ==================")

        if "Action" in str(inputs):
            return inputs
        
        else:
            if isinstance(inputs, StringPromptValue):
                user_input = inputs.text

            elif isinstance(inputs, str):
                user_input = inputs

            elif isinstance(inputs, ChatPromptValue):
                user_input = inputs.messages[-1].content



            self.chat_history.chat_history.append("Human: " + user_input)
            full_input = "\n".join(self.chat_history.chat_history) + "<CHAT_HISTORY_END>\nHuman: " + user_input # <CHAT_HISTORY_END> 문자열을 추가하여 이전 대화 내용을 구분
            return full_input
    