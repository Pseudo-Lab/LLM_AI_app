import streamlit as st
import requests

from dotenv import load_dotenv


load_dotenv()


# 이는 run_api.py에서 설정한 기본 베이스 url입니다.
backend_url = "http://localhost:8000" 




# page 설정
st.set_page_config(page_title="Lang-Secretary", page_icon=":shark:")



# 세션 상태에 대화 저장
if "messages" not in st.session_state:
    st.session_state.messages = []

# 페이지 타이틀
st.title("Lang-Secretary")
st.title("💬")

# 기존 대화 출력
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# 사용자 입력 받기
if user_prompt := st.chat_input("메시지를 입력하세요..."):
    # 사용자 메시지를 세션에 저장
    st.session_state.messages.append({"role": "user", 
                                      "content": user_prompt})
    
    # 사용자 메시지 출력
    with st.chat_message("user"):
        st.markdown(user_prompt)

    try:
        # api server에 요청을 보내는 부분
        response = requests.post(f"{backend_url}/graphbot/invoke", 
                                    json={
                                            "input": {
                                            "input": user_prompt,
                                            "route": "string",
                                            "response": "string"
                                            },
                                            "config": {},
                                            "kwargs": {}
                                        })
        

        print(response.json()) # debug
    
        # 챗봇 응답을 세션에 저장 및 응답 출력
        st.session_state.messages.append({"role": "assistant", 
                                          "content": response.json()['output']['response']})
        
        with st.chat_message("assistant"):
            st.markdown(response.json()['output']['response'])

    except Exception as e:
        # 별도의 이슈로 인해 챗봇 응답 생성에 실패한 경우.
        st.session_state.messages.append({"role": "assistant", 
                                          "content": "응답에 실패하였습니다. \nException: " + str(e)})
        
        with st.chat_message("assistant"):
            st.markdown("응답에 실패하였습니다. \nException: " + str(e))
    
    
